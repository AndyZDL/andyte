package com.andyzdl.ec;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import com.andyzdl.ec.andyzdl_core.APP.AndyZDL;

/**
*@Description: 电商框架入口
*@File: MainActivity.java
*@Author: AndyDongDong
*@Time: 2018/11/2 17:39
*
*/
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        AndyZDL.init(this)
                .withIcon(new )
                .withApiHost("www.baidu.com")
                .configure();        
    }
}
