package com.ec.andyzdl.andyzdl_annotations;

public class MyClass {
}
