package com.andyzdl.ec.andyzdl_core.APP;

public enum ConfigType {
    API_HOST,
    APPLICATION_CONTEXT,
    CONFIG_READY,
    ICON
}
